#query 1
#select * from product where price_per_unit > 10000;

#query 2
-- select * from order_ where address_id in(
-- 	select address_id from address where state = 'Punjab'
-- );

#query 3
-- select * from user where dob = "1987-3-23";

#query4
-- select * from product where vendor_id in (
-- 	select cust_id from user where first_name = 'Deepak'
-- );

#query5
-- select first_name, last_name from user where cust_id in (
-- 	select cust_id from order_ where cancellation_date is not null
-- );

#query6
-- select product_name from product where product_id in (
-- 	select product_id from cart where discount >= 10
-- );

#query7
-- select first_name, last_name from user where gender='M';

#query8
-- select sum(price_per_unit) from product where product_id in (
-- 	select product_id from cart where order_id in (
-- 		select order_id from order_ where payment_id in (
-- 			select payment_id from payment where ac_type = 'Visa'
--         )
--     )
-- );

#query 9
select product_name from product where manufacturing_date >= '2020-01-04';

select * from address where pin_code = '147001';
